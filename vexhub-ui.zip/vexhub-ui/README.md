# VexHub UI

A sleek, modern Roblox Lua UI library with 12 themes, full component support, save/load config management, and acrylic blur effects.

## Themes

| Original        | VexHub Exclusives |
|-----------------|------------------|
| Dark            | Midnight         |
| Darker          | Neon             |
| Light           | Cobalt           |
| Aqua            | Sunset           |
| Amethyst        | Forest           |
| Rose            | Crimson          |

## Quick Start

```lua
local VexHub = loadstring(game:HttpGet("YOUR_RAW_URL"))()

local Window = VexHub:CreateWindow({
    Title = "My Script",
    SubTitle = "by You",
    Theme = "Midnight",
    Size = UDim2.fromOffset(580, 460),
    Acrylic = false,
    MinimizeKey = Enum.KeyCode.LeftControl,
})

local Tab = Window:AddTab({ Title = "Main", Icon = "box" })
local Section = Tab:AddSection("Controls")

Section:AddToggle("MyToggle", {
    Title = "Enable Feature",
    Default = false,
    Callback = function(Value)
        print("Toggled:", Value)
    end,
})
```

## Components

| Component     | Method                  |
|---------------|-------------------------|
| Toggle        | `AddToggle`             |
| Slider        | `AddSlider`             |
| Button        | `AddButton`             |
| Dropdown      | `AddDropdown`           |
| Input         | `AddInput`              |
| Keybind       | `AddKeybind`            |
| Colorpicker   | `AddColorpicker`        |
| Paragraph     | `AddParagraph`          |

## Addons

### SaveManager
Saves and loads user configs to JSON files.

```lua
local SaveManager = require(script.Parent.Addons.SaveManager)
SaveManager:SetLibrary(VexHub)
SaveManager:SetFolder("VexHubSettings")
SaveManager:BuildConfigSection(SettingsTab)
SaveManager:LoadAutoloadConfig()
```

### InterfaceManager
Adds a built-in theme/acrylic/keybind settings section.

```lua
local InterfaceManager = require(script.Parent.Addons.InterfaceManager)
InterfaceManager:SetLibrary(VexHub)
InterfaceManager:SetFolder("VexHubSettings")
InterfaceManager:BuildInterfaceSection(SettingsTab)
```

## Notifications

```lua
VexHub:Notify({
    Title = "VexHub",
    Content = "Hello!",
    SubContent = "Optional subtitle",
    Duration = 5,
})
```

## Dialogs

```lua
Window:Dialog({
    Title = "Confirm",
    Content = "Are you sure?",
    Buttons = {
        { Title = "Yes", Callback = function() print("Yes") end },
        { Title = "No" },
    },
})
```

## File Structure

```
vexhub-lua/
├── README.md
├── Example.lua
├── Addons/
│   ├── SaveManager.lua
│   └── InterfaceManager.lua
└── src/
    ├── init.lua           ← Main library entry point
    ├── Creator.lua        ← Instance factory + theme engine
    ├── Icons.lua          ← Lucide icon map
    ├── Acrylic/           ← Acrylic blur effect
    ├── Packages/          ← Flipper animation library
    ├── Components/        ← Window, Tab, Section, Element, Dialog, etc.
    ├── Elements/          ← Toggle, Slider, Button, Dropdown, Input, Keybind, Colorpicker, Paragraph
    └── Themes/            ← All 12 theme files
```

## Version

3.2.0 — VexHub rebranded release with 6 exclusive themes.
