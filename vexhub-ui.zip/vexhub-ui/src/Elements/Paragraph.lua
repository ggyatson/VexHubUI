local Root = script.Parent.Parent
local Components = Root.Components

local Paragraph = {}
Paragraph.__index = Paragraph
Paragraph.__type = "Paragraph"

function Paragraph:New(Config)
	assert(Config.Title, "Paragraph - Missing Title")
	Config.Content = Config.Content or ""

	local Para = require(Components.Element)(Config.Title, Config.Content, Paragraph.Container, false)
	Para.Frame.BackgroundTransparency = 0.92
	Para.Border.Transparency = 0.6

	return Para
end

return Paragraph
