return {
	Name = "Midnight",
	Accent = Color3.fromRGB(100, 120, 255),

	AcrylicMain = Color3.fromRGB(8, 8, 18),
	AcrylicBorder = Color3.fromRGB(50, 55, 100),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(12, 12, 28), Color3.fromRGB(5, 5, 15)),
	AcrylicNoise = 0.95,

	TitleBarLine = Color3.fromRGB(40, 42, 80),
	Tab = Color3.fromRGB(100, 105, 160),

	Element = Color3.fromRGB(80, 85, 140),
	ElementBorder = Color3.fromRGB(18, 18, 38),
	InElementBorder = Color3.fromRGB(55, 58, 100),
	ElementTransparency = 0.86,

	ToggleSlider = Color3.fromRGB(80, 85, 140),
	ToggleToggled = Color3.fromRGB(0, 0, 0),

	SliderRail = Color3.fromRGB(80, 85, 140),

	DropdownFrame = Color3.fromRGB(120, 125, 185),
	DropdownHolder = Color3.fromRGB(18, 18, 38),
	DropdownBorder = Color3.fromRGB(14, 14, 30),
	DropdownOption = Color3.fromRGB(80, 85, 140),

	Keybind = Color3.fromRGB(80, 85, 140),

	Input = Color3.fromRGB(80, 85, 140),
	InputFocused = Color3.fromRGB(5, 5, 15),
	InputIndicator = Color3.fromRGB(110, 115, 175),

	Dialog = Color3.fromRGB(18, 18, 38),
	DialogHolder = Color3.fromRGB(12, 12, 28),
	DialogHolderLine = Color3.fromRGB(10, 10, 22),
	DialogButton = Color3.fromRGB(18, 18, 38),
	DialogButtonBorder = Color3.fromRGB(55, 58, 100),
	DialogBorder = Color3.fromRGB(45, 48, 90),
	DialogInput = Color3.fromRGB(22, 22, 45),
	DialogInputLine = Color3.fromRGB(110, 115, 175),

	Text = Color3.fromRGB(220, 225, 255),
	SubText = Color3.fromRGB(150, 155, 200),
	Hover = Color3.fromRGB(80, 85, 140),
	HoverChange = 0.05,
}
