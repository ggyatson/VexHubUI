return {
	Name = "Sunset",
	Accent = Color3.fromRGB(255, 100, 60),

	AcrylicMain = Color3.fromRGB(30, 15, 10),
	AcrylicBorder = Color3.fromRGB(150, 65, 40),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(200, 80, 30), Color3.fromRGB(150, 40, 10)),
	AcrylicNoise = 0.91,

	TitleBarLine = Color3.fromRGB(140, 70, 40),
	Tab = Color3.fromRGB(220, 130, 90),

	Element = Color3.fromRGB(200, 110, 70),
	ElementBorder = Color3.fromRGB(70, 30, 15),
	InElementBorder = Color3.fromRGB(140, 75, 45),
	ElementTransparency = 0.86,

	ToggleSlider = Color3.fromRGB(200, 110, 70),
	ToggleToggled = Color3.fromRGB(0, 0, 0),

	SliderRail = Color3.fromRGB(200, 110, 70),

	DropdownFrame = Color3.fromRGB(230, 150, 110),
	DropdownHolder = Color3.fromRGB(70, 30, 15),
	DropdownBorder = Color3.fromRGB(55, 22, 10),
	DropdownOption = Color3.fromRGB(200, 110, 70),

	Keybind = Color3.fromRGB(200, 110, 70),

	Input = Color3.fromRGB(200, 110, 70),
	InputFocused = Color3.fromRGB(20, 8, 4),
	InputIndicator = Color3.fromRGB(230, 140, 95),

	Dialog = Color3.fromRGB(70, 30, 15),
	DialogHolder = Color3.fromRGB(55, 22, 10),
	DialogHolderLine = Color3.fromRGB(48, 18, 8),
	DialogButton = Color3.fromRGB(70, 30, 15),
	DialogButtonBorder = Color3.fromRGB(140, 70, 40),
	DialogBorder = Color3.fromRGB(120, 60, 32),
	DialogInput = Color3.fromRGB(80, 35, 18),
	DialogInputLine = Color3.fromRGB(230, 140, 95),

	Text = Color3.fromRGB(255, 235, 220),
	SubText = Color3.fromRGB(210, 165, 140),
	Hover = Color3.fromRGB(200, 110, 70),
	HoverChange = 0.04,
}
