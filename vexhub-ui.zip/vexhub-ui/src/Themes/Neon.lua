return {
	Name = "Neon",
	Accent = Color3.fromRGB(0, 255, 170),

	AcrylicMain = Color3.fromRGB(10, 10, 10),
	AcrylicBorder = Color3.fromRGB(0, 120, 80),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(0, 30, 20), Color3.fromRGB(5, 5, 5)),
	AcrylicNoise = 0.93,

	TitleBarLine = Color3.fromRGB(0, 100, 65),
	Tab = Color3.fromRGB(0, 200, 130),

	Element = Color3.fromRGB(0, 160, 100),
	ElementBorder = Color3.fromRGB(5, 30, 20),
	InElementBorder = Color3.fromRGB(0, 100, 65),
	ElementTransparency = 0.85,

	ToggleSlider = Color3.fromRGB(0, 160, 100),
	ToggleToggled = Color3.fromRGB(0, 0, 0),

	SliderRail = Color3.fromRGB(0, 160, 100),

	DropdownFrame = Color3.fromRGB(0, 210, 140),
	DropdownHolder = Color3.fromRGB(10, 30, 22),
	DropdownBorder = Color3.fromRGB(5, 22, 15),
	DropdownOption = Color3.fromRGB(0, 160, 100),

	Keybind = Color3.fromRGB(0, 160, 100),

	Input = Color3.fromRGB(0, 160, 100),
	InputFocused = Color3.fromRGB(0, 10, 6),
	InputIndicator = Color3.fromRGB(0, 200, 130),

	Dialog = Color3.fromRGB(10, 30, 22),
	DialogHolder = Color3.fromRGB(8, 22, 16),
	DialogHolderLine = Color3.fromRGB(5, 18, 12),
	DialogButton = Color3.fromRGB(10, 30, 22),
	DialogButtonBorder = Color3.fromRGB(0, 100, 65),
	DialogBorder = Color3.fromRGB(0, 90, 58),
	DialogInput = Color3.fromRGB(12, 35, 25),
	DialogInputLine = Color3.fromRGB(0, 200, 130),

	Text = Color3.fromRGB(200, 255, 235),
	SubText = Color3.fromRGB(120, 200, 165),
	Hover = Color3.fromRGB(0, 160, 100),
	HoverChange = 0.04,
}
