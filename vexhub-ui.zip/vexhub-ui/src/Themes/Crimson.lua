return {
	Name = "Crimson",
	Accent = Color3.fromRGB(210, 30, 50),

	AcrylicMain = Color3.fromRGB(18, 6, 8),
	AcrylicBorder = Color3.fromRGB(120, 30, 40),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(90, 15, 22), Color3.fromRGB(30, 5, 8)),
	AcrylicNoise = 0.92,

	TitleBarLine = Color3.fromRGB(100, 25, 35),
	Tab = Color3.fromRGB(190, 80, 95),

	Element = Color3.fromRGB(160, 55, 70),
	ElementBorder = Color3.fromRGB(40, 10, 14),
	InElementBorder = Color3.fromRGB(110, 35, 47),
	ElementTransparency = 0.86,

	ToggleSlider = Color3.fromRGB(160, 55, 70),
	ToggleToggled = Color3.fromRGB(0, 0, 0),

	SliderRail = Color3.fromRGB(160, 55, 70),

	DropdownFrame = Color3.fromRGB(200, 100, 115),
	DropdownHolder = Color3.fromRGB(45, 12, 16),
	DropdownBorder = Color3.fromRGB(35, 8, 12),
	DropdownOption = Color3.fromRGB(160, 55, 70),

	Keybind = Color3.fromRGB(160, 55, 70),

	Input = Color3.fromRGB(160, 55, 70),
	InputFocused = Color3.fromRGB(10, 3, 4),
	InputIndicator = Color3.fromRGB(195, 80, 95),

	Dialog = Color3.fromRGB(45, 12, 16),
	DialogHolder = Color3.fromRGB(35, 8, 12),
	DialogHolderLine = Color3.fromRGB(28, 6, 9),
	DialogButton = Color3.fromRGB(45, 12, 16),
	DialogButtonBorder = Color3.fromRGB(110, 35, 47),
	DialogBorder = Color3.fromRGB(95, 28, 38),
	DialogInput = Color3.fromRGB(52, 14, 19),
	DialogInputLine = Color3.fromRGB(195, 80, 95),

	Text = Color3.fromRGB(255, 220, 225),
	SubText = Color3.fromRGB(210, 145, 155),
	Hover = Color3.fromRGB(160, 55, 70),
	HoverChange = 0.04,
}
