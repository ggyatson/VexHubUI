return {
	Name = "Cobalt",
	Accent = Color3.fromRGB(30, 120, 255),

	AcrylicMain = Color3.fromRGB(10, 18, 38),
	AcrylicBorder = Color3.fromRGB(30, 70, 150),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(15, 35, 80), Color3.fromRGB(8, 15, 35)),
	AcrylicNoise = 0.92,

	TitleBarLine = Color3.fromRGB(25, 60, 130),
	Tab = Color3.fromRGB(80, 140, 230),

	Element = Color3.fromRGB(50, 110, 200),
	ElementBorder = Color3.fromRGB(10, 22, 50),
	InElementBorder = Color3.fromRGB(35, 80, 155),
	ElementTransparency = 0.85,

	ToggleSlider = Color3.fromRGB(50, 110, 200),
	ToggleToggled = Color3.fromRGB(0, 0, 0),

	SliderRail = Color3.fromRGB(50, 110, 200),

	DropdownFrame = Color3.fromRGB(100, 160, 245),
	DropdownHolder = Color3.fromRGB(14, 30, 65),
	DropdownBorder = Color3.fromRGB(10, 22, 50),
	DropdownOption = Color3.fromRGB(50, 110, 200),

	Keybind = Color3.fromRGB(50, 110, 200),

	Input = Color3.fromRGB(50, 110, 200),
	InputFocused = Color3.fromRGB(5, 10, 25),
	InputIndicator = Color3.fromRGB(90, 145, 230),

	Dialog = Color3.fromRGB(14, 30, 65),
	DialogHolder = Color3.fromRGB(10, 22, 50),
	DialogHolderLine = Color3.fromRGB(8, 18, 40),
	DialogButton = Color3.fromRGB(14, 30, 65),
	DialogButtonBorder = Color3.fromRGB(40, 88, 170),
	DialogBorder = Color3.fromRGB(30, 75, 155),
	DialogInput = Color3.fromRGB(16, 35, 75),
	DialogInputLine = Color3.fromRGB(90, 145, 230),

	Text = Color3.fromRGB(210, 225, 255),
	SubText = Color3.fromRGB(130, 165, 230),
	Hover = Color3.fromRGB(50, 110, 200),
	HoverChange = 0.04,
}
