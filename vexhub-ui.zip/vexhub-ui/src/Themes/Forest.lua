return {
	Name = "Forest",
	Accent = Color3.fromRGB(60, 190, 90),

	AcrylicMain = Color3.fromRGB(10, 20, 12),
	AcrylicBorder = Color3.fromRGB(35, 90, 45),
	AcrylicGradient = ColorSequence.new(Color3.fromRGB(20, 55, 25), Color3.fromRGB(8, 18, 10)),
	AcrylicNoise = 0.93,

	TitleBarLine = Color3.fromRGB(30, 80, 38),
	Tab = Color3.fromRGB(90, 170, 105),

	Element = Color3.fromRGB(60, 140, 75),
	ElementBorder = Color3.fromRGB(12, 30, 15),
	InElementBorder = Color3.fromRGB(40, 100, 50),
	ElementTransparency = 0.85,

	ToggleSlider = Color3.fromRGB(60, 140, 75),
	ToggleToggled = Color3.fromRGB(0, 0, 0),

	SliderRail = Color3.fromRGB(60, 140, 75),

	DropdownFrame = Color3.fromRGB(100, 180, 115),
	DropdownHolder = Color3.fromRGB(14, 35, 18),
	DropdownBorder = Color3.fromRGB(10, 26, 13),
	DropdownOption = Color3.fromRGB(60, 140, 75),

	Keybind = Color3.fromRGB(60, 140, 75),

	Input = Color3.fromRGB(60, 140, 75),
	InputFocused = Color3.fromRGB(5, 12, 6),
	InputIndicator = Color3.fromRGB(90, 170, 105),

	Dialog = Color3.fromRGB(14, 35, 18),
	DialogHolder = Color3.fromRGB(10, 26, 13),
	DialogHolderLine = Color3.fromRGB(8, 20, 10),
	DialogButton = Color3.fromRGB(14, 35, 18),
	DialogButtonBorder = Color3.fromRGB(40, 100, 50),
	DialogBorder = Color3.fromRGB(32, 88, 42),
	DialogInput = Color3.fromRGB(16, 40, 20),
	DialogInputLine = Color3.fromRGB(90, 170, 105),

	Text = Color3.fromRGB(210, 245, 215),
	SubText = Color3.fromRGB(135, 195, 148),
	Hover = Color3.fromRGB(60, 140, 75),
	HoverChange = 0.04,
}
