--[[
	VexHub UI Library — Example Script
	Version 3.2.0

	Load via:
	local VexHub = loadstring(game:HttpGet("YOUR_RAWSCRIPT_URL"))()

	Or via model in Roblox Studio:
	local VexHub = require(PATH_TO_SRC.init)
]]

local VexHub = require(script.Parent.src)

local SaveManager = require(script.Parent.Addons.SaveManager)
local InterfaceManager = require(script.Parent.Addons.InterfaceManager)

--// Create window
local Window = VexHub:CreateWindow({
	Title = "VexHub",
	SubTitle = "by VexHub",
	Theme = "Dark",   -- "Dark","Darker","Light","Aqua","Amethyst","Rose","Midnight","Neon","Cobalt","Sunset","Forest","Crimson"
	Size = UDim2.fromOffset(580, 460),
	Acrylic = false,  -- Requires graphic quality 8+
	MinimizeKey = Enum.KeyCode.LeftControl,
})

--// Main tab
local MainTab = Window:AddTab({ Title = "Main", Icon = "box" })
local MainSection = MainTab:AddSection("Controls")

--// Toggle
MainSection:AddToggle("MyToggle", {
	Title = "Example Toggle",
	Description = "Switches something on or off",
	Default = false,
	Callback = function(Value)
		print("Toggle:", Value)
	end
})

--// Slider
MainSection:AddSlider("MySlider", {
	Title = "Example Slider",
	Description = "Drag to pick a value",
	Default = 50,
	Min = 0,
	Max = 100,
	Rounding = 0,
	Callback = function(Value)
		print("Slider:", Value)
	end
})

--// Button
MainSection:AddButton({
	Title = "Example Button",
	Description = "Click me",
	Callback = function()
		VexHub:Notify({
			Title = "VexHub",
			Content = "Button clicked!",
			Duration = 3,
		})
	end
})

--// Dropdown
MainSection:AddDropdown("MyDropdown", {
	Title = "Example Dropdown",
	Values = { "Option A", "Option B", "Option C" },
	Default = "Option A",
	Callback = function(Value)
		print("Dropdown:", Value)
	end
})

--// Input
MainSection:AddInput("MyInput", {
	Title = "Example Input",
	Placeholder = "Type here...",
	Callback = function(Value)
		print("Input:", Value)
	end
})

--// Keybind
MainSection:AddKeybind("MyKeybind", {
	Title = "Example Keybind",
	Default = "E",
	Callback = function(Toggled)
		print("Keybind toggled:", Toggled)
	end
})

--// Colorpicker
MainSection:AddColorpicker("MyColorpicker", {
	Title = "Example Colorpicker",
	Default = Color3.fromRGB(96, 205, 255),
	Callback = function(Value)
		print("Color:", Value)
	end
})

--// Paragraph
MainSection:AddParagraph({
	Title = "Info",
	Content = "VexHub UI — a sleek, theme-powered Roblox Lua interface library.",
})

--// Settings tab
local SettingsTab = Window:AddTab({ Title = "Settings", Icon = "settings" })

InterfaceManager:SetLibrary(VexHub)
InterfaceManager:SetFolder("VexHubSettings")
InterfaceManager:BuildInterfaceSection(SettingsTab)

SaveManager:SetLibrary(VexHub)
SaveManager:SetFolder("VexHubSettings")
SaveManager:IgnoreThemeSettings()
SaveManager:BuildConfigSection(SettingsTab)
SaveManager:LoadAutoloadConfig()

--// Select first tab
Window:SelectTab(1)
